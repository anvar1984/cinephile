<template>
    <main class="main">
        <SearchContent/>
    </main>
</template>

<script setup>
import SearchContent from '../components/Search/SearchContent.vue';
</script>

<style lang="scss">

</style>