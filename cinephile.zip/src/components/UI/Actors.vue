<template>
    <div class="actor" v-for="item, index in getActors" :key="item.id">
        <img v-if="item.profile_path" :src="imgUrl + item.profile_path" alt="" class="actor__img">
        <span class="actor__name">{{ item.name }}</span>
    </div>
</template>

<script setup>
const props = defineProps(['type', 'id', 'count']);
import { useActors } from "../../store/actors";
import { computed } from "vue";
import { imgUrl } from "../../static";
const actorsStore = useActors();
actorsStore.getActors(props.type, props.id, props.count);
const getActors = computed(()=> props.type == 'movie' ? actorsStore.actorsMovie : actorsStore.actorsTv)
console.log(getActors);

</script>

<style lang="scss" scoped>

</style>