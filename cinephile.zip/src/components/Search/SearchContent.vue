<template>
    <section class="search container">
        <input v-model="searchValue" type="text" class="search__input" placeholder="Найти фильм, сериал...">
    </section>
</template>

<script setup>
import SearchItem from './SearchItem.vue';
import { useSearch } from "../../store/search";
import { computed } from "vue";
const searchStore = useSearch();
const searchValue = computed({
    get: ()=>{
        return searchStore.search
    },
    set: (val)=>{
        searchStore.search = val
    }
})
searchStore.getSearch();

</script>

<style lang="scss">

</style>